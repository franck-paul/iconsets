Dotclear Metro iconset

For private used only
Icons from dAKirby309 (http://dakirby309.deviantart.com/art/Metro-UI-Dock-Icon-Set-678-Icons-280724102)

Do not distribute