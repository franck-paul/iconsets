Original Dotclear 2.4/2.5 iconset

Icons from Thomas Daveluy for Dotclear (see http://thomas-daveluy.fr/)
