IcoMoon by Keyamoon http://icomoon.io/app/
CC License (CC BY 3.0)